# Fixed-Rate Bond Yield Modeling

## Project Summary
This repository presents a fixed-rate bond yield modeling workflow built from Treasury benchmark construction, benchmark-relative spread decomposition, and bond-level analysis.

The central pricing identity is:

Yield_i = B(T_i) + S_i

where:
- B(T_i) is the Treasury benchmark rate at maturity T_i
- S_i is the credit / bond-specific spread

This repo is designed to be GitHub-presentable and job-ready. It documents:
1. the benchmark construction logic,
2. the spread decomposition,
3. the model progression,
4. the final code used for benchmark-aware modeling.

## Why this project matters
Many simple bond models try to predict yield directly from coupon, price, and maturity. That ignores the fact that fixed-income instruments are priced relative to a benchmark curve.

This project instead uses a benchmark-plus-spread framework:
1. build the Treasury curve,
2. assign a benchmark rate by maturity,
3. model the residual spread.

That is much closer to how real fixed-income systems are structured.

## Math Used

### 1. Benchmark curve
For each bond with maturity T_i, assign a Treasury benchmark:

B(T_i) = f(T_i)

where f is an interpolated Treasury curve.

### 2. Spread definition
S_i = Y_i - B(T_i)

where:
- Y_i = reported yield,
- B(T_i) = benchmark Treasury rate,
- S_i = spread over benchmark.

### 3. Regression baseline
A simple benchmark-aware model can be written as:

Y_i = B(T_i) + a + b1*C_i + b2*D_i + b3*T_i

where:
- C_i = coupon,
- D_i = 100 - P_i = discount from par,
- T_i = years to maturity.

## Project Structure
- curve_utils.py — benchmark curve loader + interpolation helper
- apply_curve.py — applies Treasury benchmark rates to trade data
- fixed_rate_baseline.py — benchmark-plus-spread baseline for fixed-rate bonds
- paper_notes.md — research-style writeup for interviews / portfolio

## Notes
This repo was reconstructed from the final workflow described in a longer modeling session. It is intended as a polished project artifact rather than a raw internal production dump.
