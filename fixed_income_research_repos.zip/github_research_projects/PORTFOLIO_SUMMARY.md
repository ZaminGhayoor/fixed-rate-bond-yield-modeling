# Portfolio Summary

## Fixed-Rate Bond Yield Modeling
This project presents a benchmark-relative framework for fixed-rate bond yield estimation. It uses a Treasury benchmark curve, spread decomposition, and a benchmark-aware baseline model.

## SOFR / Treasury Spread Modeling
This project walks through a full modeling progression:
- benchmark-plus-spread baseline,
- issuer-level model,
- shrinkage test,
- bond-level research upper bound,
- final no-leakage bond-plus-issuer model.

## Key Result
The final clean model reduced error from roughly 12 bps to roughly 6 bps by showing that bond-level structure matters materially once the benchmark curve is modeled correctly.

## Interview framing
These repos show:
- fixed-income modeling intuition,
- benchmark construction,
- spread decomposition,
- model evaluation discipline,
- attention to leakage / overfitting.
